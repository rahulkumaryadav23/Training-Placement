
package TrnPl.pojo;


public class ParticipantJobPojo extends JobPojo {
    private String companyname;

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }
    
}
