
package TrnPl.pojo;


public class ParticipantResultPojo extends ParticipantJobPojo{
    private double percentage;

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
    
    
}
