

package TrnPl.pojo;


public class CurrentUser {

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        CurrentUser.name = name;
    }

    public static String getUserId() {
        return userId;
    }

    public static void setUserId(String userId) {
        CurrentUser.userId = userId;
    }

    public static String getId() {
        return Id;
    }

    public static void setId(String Id) {
        CurrentUser.Id = Id;
    }

    public static String getType() {
        return type;
    }

    public static void setType(String type) {
        CurrentUser.type = type;
    }
    private static  String name;
    private static String userId;
    private static String Id;
    private static String type;

    

    
    
    
}
